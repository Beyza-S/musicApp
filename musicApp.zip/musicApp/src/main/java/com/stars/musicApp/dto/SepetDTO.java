package com.stars.musicApp.dto;

public class SepetDTO {
}
