package com.stars.musicApp.service;

import com.stars.musicApp.entity.SanatciRoller;

import java.util.List;

public class SanatciRollerServicempl implements SanatciRollerService {

    @Override
    public List<SanatciRoller> findAll() {
        return List.of();
    }

    @Override
    public SanatciRoller findById(int theId) {
        return null;
    }

    @Override
    public SanatciRoller save(SanatciRoller theSanatciRoller) {
        return null;
    }

    @Override
    public void delete(int theId) {

    }
}
