package com.stars.musicApp.dto;

public class UrunDTO {
}
