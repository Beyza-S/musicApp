package com.stars.musicApp.rest;

public class SanatciRollerRestController {
}
