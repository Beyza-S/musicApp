package com.stars.musicApp.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping()
public class MisafirRestController {
    //RequestMappingi ekle
}
